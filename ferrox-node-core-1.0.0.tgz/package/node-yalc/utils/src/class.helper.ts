import { ClassType } from '@node-yalc/types/globals.js';

// Check if the class is a native class (like Error, Array, etc.)
export function isNativeClass<T = any>(
  func: any,
  className?: string,
): func is ClassType<T> {
  return (
    typeof func === 'function' &&
    func.prototype?.constructor === func && // Native class constructors have this prototype constructor link
    (className ? func.name === className : true)
  );
}

// Check if the class is an ES6-style class
export function isES6Class<T = any>(
  func: any,
  className?: string,
): func is ClassType<T> {
  return (
    typeof func === 'function' &&
    /^class\s/.test(func.toString()) && // ES6 classes start with the keyword "class"
    /* istanbul ignore next */
    (className ? func.name === className : true)
  );
}

// Check if the class is either native or ES6
export function isClass<T = any>(
  func: any,
  className?: string,
): func is ClassType<T> {
  return isNativeClass(func, className) || isES6Class(func, className);
}
