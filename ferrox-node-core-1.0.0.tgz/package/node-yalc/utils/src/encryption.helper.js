"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.decryptAes = exports.encryptAes = void 0;
const tslib_1 = require("tslib");
const crypto = tslib_1.__importStar(require("crypto"));
const encryptAes = (toEncrypt, key) => {
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv('aes-256-ctr', Buffer.from(key, 'hex'), iv);
    let encrypted = cipher.update(toEncrypt, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return iv.toString('hex') + ':' + encrypted;
};
exports.encryptAes = encryptAes;
const decryptAes = (toDecrypt, key) => {
    if (toDecrypt === '') {
        return '';
    }
    const split = toDecrypt.split(':');
    const iv = split[0];
    const decipher = crypto.createDecipheriv('aes-256-ctr', Buffer.from(key, 'hex'), Buffer.from(iv, 'hex'));
    let decrypted = decipher.update(split[1], 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
};
exports.decryptAes = decryptAes;
//# sourceMappingURL=encryption.helper.js.map