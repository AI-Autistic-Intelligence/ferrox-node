# @nest-yalc-2/types-extends

## 1.3.3

### Patch Changes

- Publish npm-safe README files for every package and prevent Jekyll landing-page
  markup from being copied into npm tarballs.
